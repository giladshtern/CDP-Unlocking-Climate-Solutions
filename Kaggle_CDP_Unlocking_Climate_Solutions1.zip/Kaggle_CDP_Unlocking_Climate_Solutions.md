# CDP: Unlocking Climate Solutions

####  By Gilad Shtern 27-Nov-2020

### Introduction
CDP is a global non-profit that drives companies and governments to reduce their greenhouse gas emissions, safeguard water resources, and protect forests. Each year, CDP takes the information supplied in its annual reporting process and scores companies and cities based on their journey through disclosure and towards environmental leadership.

CDP houses the world’s largest, most comprehensive dataset on environmental action. As the data grows to include thousands more companies and cities each year, there is increasing potential for the data to be utilized in impactful ways. Because of this potential, CDP is excited to launch an analytics challenge for the Kaggle community. Data scientists will scour environmental information provided to CDP by disclosing companies and cities, searching for solutions to our most pressing problems related to climate change, water security, deforestation, and social inequity.

How do you help cities adapt to a rapidly changing climate amidst a global pandemic, but do it in a way that is socially equitable?

What are the projects that can be invested in that will help pull cities out of a recession, mitigate climate issues, but not perpetuate racial/social inequities?

What are the practical and actionable points where city and corporate ambition join, i.e. where do cities have problems that corporations affected by those problems could solve, and vice versa?

How can we measure the intersection between environmental risks and social equity, as a contributor to resiliency?

### PROBLEM STATEMENT
Develop a methodology for calculating key performance indicators (KPIs) that relate to the environmental and social issues that are discussed in the CDP survey data. Leverage external data sources and thoroughly discuss the intersection between environmental issues and social issues. Mine information to create automated insight generation demonstrating whether city and corporate ambitions take these factors into account.



## Part1 - Data Exploration for Cities Responses Questionnaires


```python
#Step1 - Aggregate csv by csv subject
import pandas as pd
import os
import nbconvert
import seaborn as sns
import warnings;
warnings.filterwarnings('ignore');

path = 'G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/'
folderList = ['G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Cities/Cities Responses',
'G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Corporations/Corporations Responses/Climate Change',
'G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Corporations/Corporations Responses/Water Security']
for i, valueA in enumerate(folderList):
    filesList = os.listdir(valueA)[0:3]
    for j, valueB in enumerate(filesList):
        df = pd.read_csv(valueA + "/" + valueB)
        if j == 0:
            df0 = df
        else:
            #df0 = pd.concat([df0,df], axis=1)
            df0 = df0.append(df)

    if len(valueA.split("/")) == 5:
        newFilePath = path + valueA.split("/")[4] + ".csv"
    else:
        newFilePath = path + valueA.split("/")[4] + " " + valueA.split("/")[5].split(" ")[0] + ".csv"
    df0.to_csv(newFilePath , index=False, sep=',', header=True)
```


```python
#Step2 - Load cities aggregate responses
Cities_Responses_df = pd.read_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Cities Responses.csv')
Cities_Responses_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Questionnaire</th>
      <th>Year Reported to CDP</th>
      <th>Account Number</th>
      <th>Organization</th>
      <th>Country</th>
      <th>CDP Region</th>
      <th>Parent Section</th>
      <th>Section</th>
      <th>Question Number</th>
      <th>Question Name</th>
      <th>Column Number</th>
      <th>Column Name</th>
      <th>Row Number</th>
      <th>Row Name</th>
      <th>Response Answer</th>
      <th>Comments</th>
      <th>File Name</th>
      <th>Last update</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>CDP Cities 2018</td>
      <td>2018</td>
      <td>3203</td>
      <td>City of Chicago</td>
      <td>United States of America</td>
      <td>North America</td>
      <td>Water</td>
      <td>Wastewater</td>
      <td>16.1</td>
      <td>Please provide the percentage breakdown of the...</td>
      <td>1</td>
      <td>Percentage of wastewater collected</td>
      <td>5</td>
      <td>Other type of wastewater</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24/06/2020 05:28:18 AM</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CDP Cities 2018</td>
      <td>2018</td>
      <td>50555</td>
      <td>City of Hamilton</td>
      <td>Canada</td>
      <td>North America</td>
      <td>Climate Hazards</td>
      <td>Climate Hazards</td>
      <td>2.2a</td>
      <td>Please list the most significant climate hazar...</td>
      <td>5</td>
      <td>Probability of hazard</td>
      <td>4</td>
      <td>NaN</td>
      <td>Medium High</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24/06/2020 05:28:18 AM</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CDP Cities 2018</td>
      <td>2018</td>
      <td>50392</td>
      <td>Prefeitura de Vitória</td>
      <td>Brazil</td>
      <td>Latin America</td>
      <td>Emissions Reduction: City-wide</td>
      <td>Emissions Reduction Actions : City-wide</td>
      <td>8.4</td>
      <td>What actions is your city taking to reduce emi...</td>
      <td>1</td>
      <td>Emissions reduction project activity</td>
      <td>3</td>
      <td>NaN</td>
      <td>On-site renewable energy generation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24/06/2020 05:28:18 AM</td>
    </tr>
    <tr>
      <th>3</th>
      <td>CDP Cities 2018</td>
      <td>2018</td>
      <td>36522</td>
      <td>Comune di Verbania</td>
      <td>Italy</td>
      <td>Europe</td>
      <td>Strategy</td>
      <td>Energy</td>
      <td>9.0</td>
      <td>Please indicate the energy mix of electricity ...</td>
      <td>2</td>
      <td>Gas</td>
      <td>1</td>
      <td>Energy consumption percentage</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24/06/2020 05:28:18 AM</td>
    </tr>
    <tr>
      <th>4</th>
      <td>CDP Cities 2018</td>
      <td>2018</td>
      <td>35873</td>
      <td>Municipality of Medellín</td>
      <td>Colombia</td>
      <td>Latin America</td>
      <td>Climate Hazards</td>
      <td>Climate Hazards</td>
      <td>2.2a</td>
      <td>Please list the most significant climate hazar...</td>
      <td>3</td>
      <td>Magnitude of impact</td>
      <td>6</td>
      <td>NaN</td>
      <td>Serious</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24/06/2020 05:28:18 AM</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Step3 - Check col types, NA, unique.
df = pd.DataFrame(columns = ['Col', 'Type', 'NA', '%NA', 'UniqLen']) 
colList = list(Cities_Responses_df)

for i, value in enumerate(colList):
    df.loc[i] = [value, Cities_Responses_df.dtypes[i], Cities_Responses_df[value].isna().sum(),  Cities_Responses_df[value].isna().sum()/len(Cities_Responses_df), len(Cities_Responses_df[value].unique())]

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Col</th>
      <th>Type</th>
      <th>NA</th>
      <th>%NA</th>
      <th>UniqLen</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Questionnaire</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Year Reported to CDP</td>
      <td>int64</td>
      <td>0</td>
      <td>0.000000</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Account Number</td>
      <td>int64</td>
      <td>0</td>
      <td>0.000000</td>
      <td>975</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Organization</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>976</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Country</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>94</td>
    </tr>
    <tr>
      <th>5</th>
      <td>CDP Region</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Parent Section</td>
      <td>object</td>
      <td>274302</td>
      <td>0.177830</td>
      <td>21</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Section</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>51</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Question Number</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>259</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Question Name</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>329</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Column Number</td>
      <td>int64</td>
      <td>0</td>
      <td>0.000000</td>
      <td>22</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Column Name</td>
      <td>object</td>
      <td>74091</td>
      <td>0.048033</td>
      <td>512</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Row Number</td>
      <td>int64</td>
      <td>0</td>
      <td>0.000000</td>
      <td>777</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Row Name</td>
      <td>object</td>
      <td>925226</td>
      <td>0.599824</td>
      <td>226</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Response Answer</td>
      <td>object</td>
      <td>401188</td>
      <td>0.260090</td>
      <td>128401</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Comments</td>
      <td>object</td>
      <td>1497767</td>
      <td>0.971002</td>
      <td>3028</td>
    </tr>
    <tr>
      <th>16</th>
      <td>File Name</td>
      <td>object</td>
      <td>1537241</td>
      <td>0.996593</td>
      <td>4160</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Last update</td>
      <td>object</td>
      <td>0</td>
      <td>0.000000</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Step4 - Handle column
#Convert Last Update into year & month
Cities_Responses_df['ResYear'] = int(Cities_Responses_df['Last update'][1].split("/")[2].split(" ")[0])
Cities_Responses_df['ResMonth'] = int(Cities_Responses_df['Last update'][1].split("/")[1])

#Convert col type:int64 -> int 32
for i, value in enumerate(colList):
    if Cities_Responses_df.dtypes[i] == 'int64' or Cities_Responses_df.dtypes[i] == 'float64':
        Cities_Responses_df[value] = Cities_Responses_df[value].astype('int32')

#Drop NA cols
Cities_Responses_df = Cities_Responses_df.drop(['Questionnaire', 'Parent Section', 'Comments', 'File Name', 'Column Name','Row Name', 'Last update'], axis=1)

#Drop specific row in which Response Answer col is NaN
Cities_Responses_df = Cities_Responses_df.dropna(subset = ['Response Answer'])
Cities_Responses_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year Reported to CDP</th>
      <th>Account Number</th>
      <th>Organization</th>
      <th>Country</th>
      <th>CDP Region</th>
      <th>Section</th>
      <th>Question Number</th>
      <th>Question Name</th>
      <th>Column Number</th>
      <th>Row Number</th>
      <th>Response Answer</th>
      <th>ResYear</th>
      <th>ResMonth</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2018</td>
      <td>50555</td>
      <td>City of Hamilton</td>
      <td>Canada</td>
      <td>North America</td>
      <td>Climate Hazards</td>
      <td>2.2a</td>
      <td>Please list the most significant climate hazar...</td>
      <td>5</td>
      <td>4</td>
      <td>Medium High</td>
      <td>2020</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2018</td>
      <td>50392</td>
      <td>Prefeitura de Vitória</td>
      <td>Brazil</td>
      <td>Latin America</td>
      <td>Emissions Reduction Actions : City-wide</td>
      <td>8.4</td>
      <td>What actions is your city taking to reduce emi...</td>
      <td>1</td>
      <td>3</td>
      <td>On-site renewable energy generation</td>
      <td>2020</td>
      <td>6</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2018</td>
      <td>35873</td>
      <td>Municipality of Medellín</td>
      <td>Colombia</td>
      <td>Latin America</td>
      <td>Climate Hazards</td>
      <td>2.2a</td>
      <td>Please list the most significant climate hazar...</td>
      <td>3</td>
      <td>6</td>
      <td>Serious</td>
      <td>2020</td>
      <td>6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>2018</td>
      <td>31155</td>
      <td>City of Buenos Aires</td>
      <td>Argentina</td>
      <td>Latin America</td>
      <td>Re-stating previous emissions inventories</td>
      <td>7.13a</td>
      <td>Please provide your city’s recalculated total ...</td>
      <td>4</td>
      <td>2</td>
      <td>13434140</td>
      <td>2020</td>
      <td>6</td>
    </tr>
    <tr>
      <th>7</th>
      <td>2018</td>
      <td>59653</td>
      <td>City of Manhattan Beach, CA</td>
      <td>United States of America</td>
      <td>North America</td>
      <td>GHG Emissions Data</td>
      <td>7.11</td>
      <td>Please indicate if your city-wide emissions ha...</td>
      <td>3</td>
      <td>1</td>
      <td>Improvement in electricity grid renewable ener...</td>
      <td>2020</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>



### Part2 - Analyze cities questionnaires to find KPIs questions 

In this part, I will try to analyze cities responses questionnaires to find which question are most likely to be related with climate issues by using NLP. at the end of this part, we can assume to keep with clean dataset.


```python
#Step5 - Question NLP check
#Create empty DF: Question Number, Question Name, Question Keywords, Climate Keywords
cities_keywords_df = pd.DataFrame(columns=['Question Number', 'Question Name', 'Question Keywords', 'Climate Keywords'])

#Keep unique questions for NLP check
cities_keywords_df['Question Number'] = Cities_Responses_df['Question Number']
cities_keywords_df['Question Name'] = Cities_Responses_df['Question Name']
cities_keywords_df['Question Keywords'] = ''
cities_keywords_df['Climate Keywords'] = ''

cities_keywords_df = cities_keywords_df.drop_duplicates(subset=['Question Number', 'Question Name'], keep="first")
cities_keywords_df.head()

#NLP
from nltk.tokenize import sent_tokenize
import nltk
en_stop = set(nltk.corpus.stopwords.words('english'))
from nltk.stem import WordNetLemmatizer
import re

stemmer = WordNetLemmatizer()
#Preprocess func
def preprocess_text(document):
    # Remove all the special characters
    document = re.sub(r'\W', ' ', str(document))
    # remove all single characters
    document = re.sub(r'\s+[a-zA-Z]\s+', ' ', document)
    # Remove single characters from the start
    document = re.sub(r'\^[a-zA-Z]\s+', ' ', document)
    # Substituting multiple spaces with single space
    document = re.sub(r'\s+', ' ', document, flags=re.I)
    # Removing prefixed 'b'
    document = re.sub(r'^b\s+', '', document)
    # Converting to Lowercase
    document = document.lower()
    # Lemmatization
    tokens = document.split()
    tokens = [stemmer.lemmatize(word) for word in tokens]
    tokens = [word for word in tokens if word not in en_stop]
    tokens = [word for word in tokens if len(word) > 3]
    preprocessed_text = ' '.join(tokens)
    return preprocessed_text

for i, value in enumerate(cities_keywords_df['Question Name']):
    text = sent_tokenize(str(value))
    cities_keywords_df['Question Keywords'].iloc[i] = preprocess_text(text)
    
cities_keywords_df.head()

#Create list of climate/pollusion dictionary
climate_change_keywords = ['carbon', 'dioxide', 'greenhouse', 'ghg', 'co2', 'emissions', 'extreme weather', 'global warming', 'climate change', 'fossil fuels','sea-level rise', 'global average temperature', 'renewable energy', 'methane', 'atmosphere', 'melt', 'waste', 'smoke', 'smog', 'sulfur', 'nitrates', 'harmful', 'hazard', 'fire', 'damage', 'acid']

#Check if col keyword contains climate/Greenhouse  keywords
for i in range(0, len(cities_keywords_df)):
    question_keywords = list(cities_keywords_df['Question Keywords'].iloc[i].split(" "))
    counter = 0
    for j, value in enumerate(question_keywords):
        try: 
            climate_change_keywords.index(value)
            counter += 1
            cities_keywords_df['Climate Keywords'].iloc[i] = counter
            
        except:
            {}

cities_keywords_df.to_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_keywords_df.csv', index=False)
cities_keywords_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Question Number</th>
      <th>Question Name</th>
      <th>Question Keywords</th>
      <th>Climate Keywords</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2.2a</td>
      <td>Please list the most significant climate hazar...</td>
      <td>please list significant climate hazard faced c...</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8.4</td>
      <td>What actions is your city taking to reduce emi...</td>
      <td>action city taking reduce emission please also...</td>
      <td></td>
    </tr>
    <tr>
      <th>6</th>
      <td>7.13a</td>
      <td>Please provide your city’s recalculated total ...</td>
      <td>please provide city recalculated total city wi...</td>
      <td></td>
    </tr>
    <tr>
      <th>7</th>
      <td>7.11</td>
      <td>Please indicate if your city-wide emissions ha...</td>
      <td>please indicate city wide emission increased d...</td>
      <td></td>
    </tr>
    <tr>
      <th>10</th>
      <td>1.2</td>
      <td>Please describe the administrative structure o...</td>
      <td>please describe administrative structure gover...</td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
#Step6 - find Cities KPI impact questions
cities_keywords_df['Climate Keywords'] = pd.to_numeric(cities_keywords_df['Climate Keywords'])
cities_keywords_df['Climate Keywords'].hist()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x233d2deee50>




![png](output_10_1.png)


Upon the above analysis, we can distinguish between question that contain less than at least 2 climate/greenhouse keywords with those that have more than 2 climate greenhouse keywords.
Hence, we should remove all non significant questions from the cities aggregate responses.


```python
#Step7 - Clean Cities Responses dataset
#Keep question numbers list for remove
remove_question_df = cities_keywords_df[cities_keywords_df['Climate Keywords'] <2]
remove_question_list = list(remove_question_df['Question Number'])

for i, value in enumerate(remove_question_list):
    Cities_Responses_df = Cities_Responses_df[Cities_Responses_df['Question Number'] != value]
    
Cities_Responses_df.to_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_responses_clean_df.csv', index=False)
```

### Part3 - Analyze climate impact keywords in matrix answers

Now, that we left with clean dataset in which contains climate KPI questions. We need to allocate climate impact answers.
However, our answers are build in a non formal matrix way. In regular rectangle matrix, our celss would be N*M. But on this questionnaires asnwers could be found with a diferent row number per a column; col A may have 3 rows, while col D may have 5 rows.
Let raise up our assumptions:
-  Assumption1: Most cities answer won't have any climate keywords.
-  Assumption2: By, contrast, sensitive climate cities will have climate keywords.

Once again, I will use NLP analysis.


```python
#Step8 - Clean answers for calc answer matrix
Cities_Responses_df = pd.read_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_responses_clean_df.csv')

#Add col clean text
Cities_Responses_df['Answer Keywords'] = ''

#Insert clean text into col
for i in range(0, len(Cities_Responses_df)):
    text = sent_tokenize(Cities_Responses_df['Response Answer'].iloc[i])
    Cities_Responses_df['Answer Keywords'].iloc[i] = preprocess_text(text)

```


```python
#Step9 - Calc most climate impact answer cells
#Create answer keywords col
Cities_Responses_df['Climate Keywords'] = ''

#Create list of climate/pollusion keywords
climate_change_keywords = ['carbon', 'dioxide', 'greenhouse', 'ghg', 'co2', 'emissions', 'extreme weather', 'global warming', 'climate change', 'fossil fuels','sea-level rise', 'global average temperature', 'renewable energy', 'methane', 'atmosphere', 'melt', 'waste', 'smoke', 'smog', 'sulfur', 'nitrates', 'harmful', 'hazard', 'fire', 'damage', 'acid']

#Check if col keyword contains climate/pollusion/Greenhouse
for i in range(0, len(Cities_Responses_df)):
    question_keywords = list(str(Cities_Responses_df['Answer Keywords'].iloc[i]).split(" "))
    counter = 0
    for j, value in enumerate(question_keywords):
        try:
            climate_change_keywords.index(value)
            counter += 1
        except:
            {}
    Cities_Responses_df['Climate Keywords'].iloc[i] = counter

Cities_Responses_df = Cities_Responses_df.drop(['Question Name', 'Response Answer', 'Answer Keywords'], axis=1)
Cities_Responses_df['FullAnswerID'] = Cities_Responses_df['Question Number'] + "." + Cities_Responses_df['Column Number'].map(str) + "." + Cities_Responses_df['Row Number'].map(str)
Cities_Responses_df.to_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_responses_clean_df1.csv', index=False)
```


```python
#Step10 - Display year trend by region as factor climate keywords
Cities_Responses_clean_df = pd.read_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_responses_clean_df1.csv')
Cities_Responses_orig_df = pd.read_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Cities Responses.csv')
RegionClimateByYearDF = pd.DataFrame(columns=['CDP Region', 'Year', 'Climate Ratio'])
CDPRegionList = set(Cities_Responses_clean_df['CDP Region'])
YearList = [2018, 2019, 2020]
k = 0
for i, valueA in enumerate(CDPRegionList):
    for j, valueB in enumerate(YearList):
        df0 = Cities_Responses_orig_df[Cities_Responses_orig_df['CDP Region'] == valueA]
        df1 = Cities_Responses_clean_df[Cities_Responses_clean_df['CDP Region'] == valueA]
        df0 = df0[df0['Year Reported to CDP'] == valueB]
        df1 = df1[df1['Year Reported to CDP'] == valueB]
        RegionClimateByYearDF.loc[k] = [valueA, valueB, int(df1['Climate Keywords'].sum()/len(df0) * 100)]
        k += 1

sns.catplot(x="Year", y="Climate Ratio", hue="CDP Region", kind="bar", data=RegionClimateByYearDF)
```




    <seaborn.axisgrid.FacetGrid at 0x233da4aa070>




![png](output_16_1.png)


In the above graph, we see climate ratio trend by CDP regions & years. As example, Southeast Asis & Oceania climate keyword ration was reduced fromm 8% to 3% between 2018 to 2019. Also, North America reduced from 4% to 1%.

### Part4 - Build A Model

At this point, we can build an classification problem ML model. As prepare, dataset should be convert into numeric. Then, we will compare between models & choose one.


```python
#Step11 - Dictionary
dic = {}
objList = []
colList = list(Cities_Responses_clean_df)
#Create list of all object col
for i, value in enumerate(colList):
    #Per each object col, find unique values and add into list.
    if Cities_Responses_clean_df[value].dtype == 'object':
        objList += list(Cities_Responses_clean_df[value].unique())

#Remove duplicate from list and 'nan'
objList = list(set(objList))

#Build dic with values
for i, value in enumerate(objList):
    dic[value] = (i + 3) * 4 - 1
    #Go over dic and replace strings into numeric
    Cities_Responses_clean_df= Cities_Responses_clean_df.replace(value, dic[value])

for i in range(0, len(Cities_Responses_clean_df)):
    if Cities_Responses_clean_df['Climate Keywords'].iloc[i] > 0:
        Cities_Responses_clean_df['Climate Keywords'].iloc[i] = 1

#Save dic
import pickle
file_to_write = open("G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/dic.pickle", "wb")
pickle.dump(dic, file_to_write)
#Save df
Cities_Responses_clean_df.to_csv('G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/cities_convert_numeric.csv', index=False)
```


```python
#Step12 - ML PycCaret
from pycaret.classification import *

exp1 = setup(Cities_Responses_clean_df, target = 'Climate Keywords')
```

     
    Setup Succesfully Completed!
    


<style  type="text/css" >
</style><table id="T_229f5358_2f52_11eb_9a73_94de8078c78e" ><thead>    <tr>        <th class="blank level0" ></th>        <th class="col_heading level0 col0" >Description</th>        <th class="col_heading level0 col1" >Value</th>    </tr></thead><tbody>
                <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row0" class="row_heading level0 row0" >0</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow0_col0" class="data row0 col0" >session_id</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow0_col1" class="data row0 col1" >2123</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row1" class="row_heading level0 row1" >1</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow1_col0" class="data row1 col0" >Target Type</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow1_col1" class="data row1 col1" >Binary</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row2" class="row_heading level0 row2" >2</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow2_col0" class="data row2 col0" >Label Encoded</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow2_col1" class="data row2 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row3" class="row_heading level0 row3" >3</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow3_col0" class="data row3 col0" >Original Data</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow3_col1" class="data row3 col1" >(881739, 13)</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row4" class="row_heading level0 row4" >4</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow4_col0" class="data row4 col0" >Missing Values </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow4_col1" class="data row4 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row5" class="row_heading level0 row5" >5</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow5_col0" class="data row5 col0" >Numeric Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow5_col1" class="data row5 col1" >7</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row6" class="row_heading level0 row6" >6</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow6_col0" class="data row6 col0" >Categorical Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow6_col1" class="data row6 col1" >3</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row7" class="row_heading level0 row7" >7</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow7_col0" class="data row7 col0" >Ordinal Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow7_col1" class="data row7 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row8" class="row_heading level0 row8" >8</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow8_col0" class="data row8 col0" >High Cardinality Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow8_col1" class="data row8 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row9" class="row_heading level0 row9" >9</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow9_col0" class="data row9 col0" >High Cardinality Method </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow9_col1" class="data row9 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row10" class="row_heading level0 row10" >10</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow10_col0" class="data row10 col0" >Sampled Data</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow10_col1" class="data row10 col1" >(793565, 13)</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row11" class="row_heading level0 row11" >11</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow11_col0" class="data row11 col0" >Transformed Train Set</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow11_col1" class="data row11 col1" >(555495, 44)</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row12" class="row_heading level0 row12" >12</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow12_col0" class="data row12 col0" >Transformed Test Set</td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow12_col1" class="data row12 col1" >(238070, 44)</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row13" class="row_heading level0 row13" >13</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow13_col0" class="data row13 col0" >Numeric Imputer </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow13_col1" class="data row13 col1" >mean</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row14" class="row_heading level0 row14" >14</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow14_col0" class="data row14 col0" >Categorical Imputer </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow14_col1" class="data row14 col1" >constant</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row15" class="row_heading level0 row15" >15</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow15_col0" class="data row15 col0" >Normalize </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow15_col1" class="data row15 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row16" class="row_heading level0 row16" >16</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow16_col0" class="data row16 col0" >Normalize Method </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow16_col1" class="data row16 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row17" class="row_heading level0 row17" >17</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow17_col0" class="data row17 col0" >Transformation </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow17_col1" class="data row17 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row18" class="row_heading level0 row18" >18</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow18_col0" class="data row18 col0" >Transformation Method </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow18_col1" class="data row18 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row19" class="row_heading level0 row19" >19</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow19_col0" class="data row19 col0" >PCA </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow19_col1" class="data row19 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row20" class="row_heading level0 row20" >20</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow20_col0" class="data row20 col0" >PCA Method </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow20_col1" class="data row20 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row21" class="row_heading level0 row21" >21</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow21_col0" class="data row21 col0" >PCA Components </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow21_col1" class="data row21 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row22" class="row_heading level0 row22" >22</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow22_col0" class="data row22 col0" >Ignore Low Variance </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow22_col1" class="data row22 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row23" class="row_heading level0 row23" >23</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow23_col0" class="data row23 col0" >Combine Rare Levels </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow23_col1" class="data row23 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row24" class="row_heading level0 row24" >24</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow24_col0" class="data row24 col0" >Rare Level Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow24_col1" class="data row24 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row25" class="row_heading level0 row25" >25</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow25_col0" class="data row25 col0" >Numeric Binning </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow25_col1" class="data row25 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row26" class="row_heading level0 row26" >26</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow26_col0" class="data row26 col0" >Remove Outliers </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow26_col1" class="data row26 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row27" class="row_heading level0 row27" >27</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow27_col0" class="data row27 col0" >Outliers Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow27_col1" class="data row27 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row28" class="row_heading level0 row28" >28</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow28_col0" class="data row28 col0" >Remove Multicollinearity </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow28_col1" class="data row28 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row29" class="row_heading level0 row29" >29</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow29_col0" class="data row29 col0" >Multicollinearity Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow29_col1" class="data row29 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row30" class="row_heading level0 row30" >30</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow30_col0" class="data row30 col0" >Clustering </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow30_col1" class="data row30 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row31" class="row_heading level0 row31" >31</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow31_col0" class="data row31 col0" >Clustering Iteration </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow31_col1" class="data row31 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row32" class="row_heading level0 row32" >32</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow32_col0" class="data row32 col0" >Polynomial Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow32_col1" class="data row32 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row33" class="row_heading level0 row33" >33</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow33_col0" class="data row33 col0" >Polynomial Degree </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow33_col1" class="data row33 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row34" class="row_heading level0 row34" >34</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow34_col0" class="data row34 col0" >Trignometry Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow34_col1" class="data row34 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row35" class="row_heading level0 row35" >35</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow35_col0" class="data row35 col0" >Polynomial Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow35_col1" class="data row35 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row36" class="row_heading level0 row36" >36</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow36_col0" class="data row36 col0" >Group Features </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow36_col1" class="data row36 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row37" class="row_heading level0 row37" >37</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow37_col0" class="data row37 col0" >Feature Selection </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow37_col1" class="data row37 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row38" class="row_heading level0 row38" >38</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow38_col0" class="data row38 col0" >Features Selection Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow38_col1" class="data row38 col1" >None</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row39" class="row_heading level0 row39" >39</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow39_col0" class="data row39 col0" >Feature Interaction </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow39_col1" class="data row39 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row40" class="row_heading level0 row40" >40</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow40_col0" class="data row40 col0" >Feature Ratio </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow40_col1" class="data row40 col1" >False</td>
            </tr>
            <tr>
                        <th id="T_229f5358_2f52_11eb_9a73_94de8078c78elevel0_row41" class="row_heading level0 row41" >41</th>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow41_col0" class="data row41 col0" >Interaction Threshold </td>
                        <td id="T_229f5358_2f52_11eb_9a73_94de8078c78erow41_col1" class="data row41 col1" >None</td>
            </tr>
    </tbody></table>



```python
#Step13 - Model comparision
compare_models()
```




<style  type="text/css" >
    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78e th {
          text-align: left;
    }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col1 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col2 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col4 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col5 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col6 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col3 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col6 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col0 {
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col1 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col2 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col3 {
            background-color:  yellow;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col4 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col5 {
            : ;
            text-align:  left;
        }    #T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col6 {
            : ;
            text-align:  left;
        }</style><table id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78e" ><thead>    <tr>        <th class="blank level0" ></th>        <th class="col_heading level0 col0" >Model</th>        <th class="col_heading level0 col1" >Accuracy</th>        <th class="col_heading level0 col2" >AUC</th>        <th class="col_heading level0 col3" >Recall</th>        <th class="col_heading level0 col4" >Prec.</th>        <th class="col_heading level0 col5" >F1</th>        <th class="col_heading level0 col6" >Kappa</th>    </tr></thead><tbody>
                <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row0" class="row_heading level0 row0" >0</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col0" class="data row0 col0" >CatBoost Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col1" class="data row0 col1" >0.978000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col2" class="data row0 col2" >0.949200</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col3" class="data row0 col3" >0.139900</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col4" class="data row0 col4" >0.756800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col5" class="data row0 col5" >0.236100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow0_col6" class="data row0 col6" >0.230200</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row1" class="row_heading level0 row1" >1</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col0" class="data row1 col0" >Light Gradient Boosting Machine</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col1" class="data row1 col1" >0.977400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col2" class="data row1 col2" >0.940000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col3" class="data row1 col3" >0.091700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col4" class="data row1 col4" >0.830500</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col5" class="data row1 col5" >0.165100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow1_col6" class="data row1 col6" >0.161000</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row2" class="row_heading level0 row2" >2</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col0" class="data row2 col0" >Gradient Boosting Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col1" class="data row2 col1" >0.976400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col2" class="data row2 col2" >0.873600</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col3" class="data row2 col3" >0.037000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col4" class="data row2 col4" >0.873300</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col5" class="data row2 col5" >0.070900</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow2_col6" class="data row2 col6" >0.069100</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row3" class="row_heading level0 row3" >3</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col0" class="data row3 col0" >Extreme Gradient Boosting</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col1" class="data row3 col1" >0.976100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col2" class="data row3 col2" >0.870600</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col3" class="data row3 col3" >0.019100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col4" class="data row3 col4" >0.958400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col5" class="data row3 col5" >0.037400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow3_col6" class="data row3 col6" >0.036500</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row4" class="row_heading level0 row4" >4</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col0" class="data row4 col0" >Random Forest Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col1" class="data row4 col1" >0.976000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col2" class="data row4 col2" >0.804700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col3" class="data row4 col3" >0.176000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col4" class="data row4 col4" >0.519100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col5" class="data row4 col5" >0.262800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow4_col6" class="data row4 col6" >0.253600</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row5" class="row_heading level0 row5" >5</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col0" class="data row5 col0" >Ada Boost Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col1" class="data row5 col1" >0.975800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col2" class="data row5 col2" >0.819600</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col3" class="data row5 col3" >0.013800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col4" class="data row5 col4" >0.643000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col5" class="data row5 col5" >0.027000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow5_col6" class="data row5 col6" >0.025900</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row6" class="row_heading level0 row6" >6</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col0" class="data row6 col0" >Logistic Regression</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col1" class="data row6 col1" >0.975700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col2" class="data row6 col2" >0.568800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col3" class="data row6 col3" >0.004800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col4" class="data row6 col4" >0.427800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col5" class="data row6 col5" >0.009500</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow6_col6" class="data row6 col6" >0.009000</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row7" class="row_heading level0 row7" >7</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col0" class="data row7 col0" >Ridge Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col1" class="data row7 col1" >0.975700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col2" class="data row7 col2" >0.000000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col3" class="data row7 col3" >0.002100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col4" class="data row7 col4" >0.474000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col5" class="data row7 col5" >0.004100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow7_col6" class="data row7 col6" >0.003900</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row8" class="row_heading level0 row8" >8</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col0" class="data row8 col0" >Extra Trees Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col1" class="data row8 col1" >0.975000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col2" class="data row8 col2" >0.837700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col3" class="data row8 col3" >0.206700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col4" class="data row8 col4" >0.468000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col5" class="data row8 col5" >0.286700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow8_col6" class="data row8 col6" >0.275900</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row9" class="row_heading level0 row9" >9</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col0" class="data row9 col0" >K Neighbors Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col1" class="data row9 col1" >0.974500</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col2" class="data row9 col2" >0.660400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col3" class="data row9 col3" >0.039100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col4" class="data row9 col4" >0.307700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col5" class="data row9 col5" >0.069400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow9_col6" class="data row9 col6" >0.064200</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row10" class="row_heading level0 row10" >10</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col0" class="data row10 col0" >Linear Discriminant Analysis</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col1" class="data row10 col1" >0.973100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col2" class="data row10 col2" >0.689000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col3" class="data row10 col3" >0.052100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col4" class="data row10 col4" >0.252300</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col5" class="data row10 col5" >0.086100</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow10_col6" class="data row10 col6" >0.078400</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row11" class="row_heading level0 row11" >11</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col0" class="data row11 col0" >Naive Bayes</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col1" class="data row11 col1" >0.972700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col2" class="data row11 col2" >0.582700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col3" class="data row11 col3" >0.020000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col4" class="data row11 col4" >0.122400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col5" class="data row11 col5" >0.034400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow11_col6" class="data row11 col6" >0.027800</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row12" class="row_heading level0 row12" >12</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col0" class="data row12 col0" >Decision Tree Classifier</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col1" class="data row12 col1" >0.969400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col2" class="data row12 col2" >0.667400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col3" class="data row12 col3" >0.345300</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col4" class="data row12 col4" >0.364500</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col5" class="data row12 col5" >0.354600</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow12_col6" class="data row12 col6" >0.338900</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row13" class="row_heading level0 row13" >13</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col0" class="data row13 col0" >SVM - Linear Kernel</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col1" class="data row13 col1" >0.968800</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col2" class="data row13 col2" >0.000000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col3" class="data row13 col3" >0.014200</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col4" class="data row13 col4" >0.082400</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col5" class="data row13 col5" >0.016000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow13_col6" class="data row13 col6" >0.008100</td>
            </tr>
            <tr>
                        <th id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78elevel0_row14" class="row_heading level0 row14" >14</th>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col0" class="data row14 col0" >Quadratic Discriminant Analysis</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col1" class="data row14 col1" >0.038000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col2" class="data row14 col2" >0.703700</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col3" class="data row14 col3" >0.996000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col4" class="data row14 col4" >0.024600</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col5" class="data row14 col5" >0.048000</td>
                        <td id="T_68fbe811_2f5f_11eb_9f0f_94de8078c78erow14_col6" class="data row14 col6" >0.000500</td>
            </tr>
    </tbody></table>




```python
#Step14 -  train logistic regression model
lgbms = create_model('lightgbm')
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Accuracy</th>
      <th>AUC</th>
      <th>Recall</th>
      <th>Prec.</th>
      <th>F1</th>
      <th>Kappa</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.9774</td>
      <td>0.9392</td>
      <td>0.0962</td>
      <td>0.8025</td>
      <td>0.1717</td>
      <td>0.1674</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.9775</td>
      <td>0.9378</td>
      <td>0.0932</td>
      <td>0.8289</td>
      <td>0.1676</td>
      <td>0.1634</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.9777</td>
      <td>0.9443</td>
      <td>0.0947</td>
      <td>0.8951</td>
      <td>0.1712</td>
      <td>0.1674</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.9776</td>
      <td>0.9388</td>
      <td>0.1021</td>
      <td>0.8214</td>
      <td>0.1816</td>
      <td>0.1772</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.9773</td>
      <td>0.9428</td>
      <td>0.0858</td>
      <td>0.8227</td>
      <td>0.1554</td>
      <td>0.1515</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.9776</td>
      <td>0.9384</td>
      <td>0.1021</td>
      <td>0.8313</td>
      <td>0.1818</td>
      <td>0.1774</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.9774</td>
      <td>0.9404</td>
      <td>0.0851</td>
      <td>0.8456</td>
      <td>0.1546</td>
      <td>0.1508</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.9771</td>
      <td>0.9353</td>
      <td>0.0769</td>
      <td>0.8062</td>
      <td>0.1404</td>
      <td>0.1368</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.9773</td>
      <td>0.9395</td>
      <td>0.0902</td>
      <td>0.8026</td>
      <td>0.1622</td>
      <td>0.1581</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.9775</td>
      <td>0.9433</td>
      <td>0.0910</td>
      <td>0.8483</td>
      <td>0.1643</td>
      <td>0.1604</td>
    </tr>
    <tr>
      <th>Mean</th>
      <td>0.9774</td>
      <td>0.9400</td>
      <td>0.0917</td>
      <td>0.8305</td>
      <td>0.1651</td>
      <td>0.1610</td>
    </tr>
    <tr>
      <th>SD</th>
      <td>0.0002</td>
      <td>0.0026</td>
      <td>0.0074</td>
      <td>0.0265</td>
      <td>0.0121</td>
      <td>0.0119</td>
    </tr>
  </tbody>
</table>
</div>



```python
save_experiment(experiment_name = 'G:/DataScienceProject/Kaggle_cdp-unlocking-climate-solutions/Exp1')
```

    Experiment Succesfully Saved
    


```python
# summary plot
interpret_model(lgbms)
# correlation plot
interpret_model(lgbms, plot = 'correlation')
```


![png](output_24_0.png)



![png](output_24_1.png)


### Conclussion

To summarize the answer for develop a methode for calculate KPIs that relate to the environmental and social issues that are discussed in the CDP survey data, we van suggest the followed:
- Find KPI question from the qyestionnaires by use of NLP.
- Use Light Gradient Boosting Machine model analyze the answers. Main KPI's: row number, section & question number.

Enjoy,
Gilad


```python

```
